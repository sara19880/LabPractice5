﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace First_web_App.Pages;

public class PrivacyModel : PageModel
{
    [BindProperty (SupportsGet =true)]
    public string N { get; set; }
    [BindProperty(SupportsGet = true)]
    public string d { get; set; }
    private readonly ILogger<PrivacyModel> _logger;

    public PrivacyModel(ILogger<PrivacyModel> logger)
    {
        _logger = logger;
    }

    public void OnGet()
    {
    }
}



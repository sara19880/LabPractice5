﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Xml.Linq;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace First_web_App.Pages
{
	public class creationModel : PageModel

    {
        [BindProperty(SupportsGet = true)]
        public List<string> tasks { get; set; }
        [BindProperty]
        public string task { get; set; }
        

        public void OnGet()
        {
            tasks.Add(task);
        }


        public IActionResult OnPost()
        {
            tasks.Add(task);
            return RedirectToPage("/index", new { newtask = tasks });
        }


        


    }
}
